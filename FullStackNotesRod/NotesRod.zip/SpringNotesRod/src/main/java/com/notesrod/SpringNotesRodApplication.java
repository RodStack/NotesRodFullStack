package com.notesrod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringNotesRodApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringNotesRodApplication.class, args);
	}

}
