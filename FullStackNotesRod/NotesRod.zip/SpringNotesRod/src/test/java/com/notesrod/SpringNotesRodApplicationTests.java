package com.notesrod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringNotesRodApplicationTests {

	@Test
	void contextLoads() {
	}

}
